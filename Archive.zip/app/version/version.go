// This is the Apps version
package version

// This is a snapshot of the version of the app.
// This is changed during the build process
// The actual version is saved in version.txt
var Version = "1.0.0-development"
